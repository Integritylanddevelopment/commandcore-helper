from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "seo_optimizer",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for seo_optimizer."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
