from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "content_curator",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for content_curator."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
