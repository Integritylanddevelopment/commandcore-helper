from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "ops_planner",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for ops_planner."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
