from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "bug_reporter",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for bug_reporter."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
