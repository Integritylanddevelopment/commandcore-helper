from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "ui_evaluator",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for ui_evaluator."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
