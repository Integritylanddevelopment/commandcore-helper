from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "support_agent",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for support_agent."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
