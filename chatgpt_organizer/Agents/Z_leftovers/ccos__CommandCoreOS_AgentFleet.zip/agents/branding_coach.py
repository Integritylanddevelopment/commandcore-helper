from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "branding_coach",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for branding_coach."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
