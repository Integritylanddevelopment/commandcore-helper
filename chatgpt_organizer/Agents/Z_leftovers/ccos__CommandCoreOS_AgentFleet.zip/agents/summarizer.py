from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "summarizer",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for summarizer."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
