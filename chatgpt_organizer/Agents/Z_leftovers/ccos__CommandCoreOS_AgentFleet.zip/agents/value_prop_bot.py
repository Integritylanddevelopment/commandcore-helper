from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "value_prop_bot",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for value_prop_bot."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
