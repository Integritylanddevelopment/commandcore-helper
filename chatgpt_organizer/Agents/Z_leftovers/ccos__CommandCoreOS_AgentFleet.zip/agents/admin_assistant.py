from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "admin_assistant",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for admin_assistant."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
