from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "influencer_outreach",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for influencer_outreach."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
