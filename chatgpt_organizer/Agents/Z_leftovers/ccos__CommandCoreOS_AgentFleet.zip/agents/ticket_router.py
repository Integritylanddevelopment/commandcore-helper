from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "ticket_router",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for ticket_router."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
