from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "compliance_checker",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for compliance_checker."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
