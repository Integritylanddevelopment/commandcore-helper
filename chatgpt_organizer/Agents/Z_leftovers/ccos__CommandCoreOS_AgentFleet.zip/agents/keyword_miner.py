from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "keyword_miner",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for keyword_miner."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
