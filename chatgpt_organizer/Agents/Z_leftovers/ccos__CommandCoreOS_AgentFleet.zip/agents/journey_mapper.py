from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "journey_mapper",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for journey_mapper."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
