from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "onboarding_coach",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for onboarding_coach."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
