from agent_core import run_agent

AGENT_CONFIG = {
    "agent_id": "infra_monitor",
    "style": "auto-generated",
    "system_prompt": "Placeholder system prompt for infra_monitor."
}

def run(prompt: str):
    return run_agent(prompt, AGENT_CONFIG)
