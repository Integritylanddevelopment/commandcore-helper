# 🧠 CommandCore Agent Suite

This document contains an overview of the full CommandCore AI agent fleet.

---

## Structure

Each agent resides in its own folder with the following format:

```
📁 agent_name/
├── logic/       # Core execution code
├── docs/        # Description and logic overview
├── status/      # Version, audit, and status
├── scripts/     # Optional helper scripts
├── metadata/    # Domain-specific definitions or context
```

All agents are orchestrated through the `agent_core` engine and registered via `agent_index`.

---

## Invocation Flow

```python
from agent_core.logic.agent_core import AgentCore

core = AgentCore()
response = core.run({
    "target_agent": "value_prop_bot",
    "input": "What is our product’s unique value?"
})
```
